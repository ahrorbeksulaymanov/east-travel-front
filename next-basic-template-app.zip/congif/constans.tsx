export const BASE_URL = "http://86.106.181.30:8888/api";
export const FILE_URL = "http://86.106.181.30:8888/api/file/"; 
